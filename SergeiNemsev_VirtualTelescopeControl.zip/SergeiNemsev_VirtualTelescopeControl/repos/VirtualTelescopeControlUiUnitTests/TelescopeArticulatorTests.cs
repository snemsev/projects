﻿
// Test Framework Libraries
using TEST = Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

// My Libraries
using MY = VirtualTelescopeControlUI;

namespace VirtualTelescopeControlUiUnitTests
{
    [TEST.TestClass]
    public class TelescopeArticulatorTests
    {
        [TEST.TestMethod]
        public void SlewRightTest()
        {
            float startAz = 0;
            int pulseDtMs = 100;
            int azRate = 10;

            MY.TelescopeArticulator articulator =
                new MY.TelescopeArticulator(0, 10, startAz, azRate, pulseDtMs);

            TEST.Assert.AreEqual(startAz, articulator.CurAz);

            float expected = articulator.CurAz + (float)(azRate / 1000.0 * pulseDtMs);
            articulator.MoveRight();
            TEST.Assert.AreEqual(expected, articulator.CurAz);
        }

        [TEST.TestMethod]
        public void SlewDownTest()
        {
            float startAlt = 0;
            int altRate = 10;
            int pulseDtMs = 100;

            MY.TelescopeArticulator articulator =
                new MY.TelescopeArticulator(startAlt, altRate, 0, 10, pulseDtMs);

            TEST.Assert.AreEqual(startAlt, articulator.CurAlt);

            float expected = articulator.CurAlt - (float)(altRate / 1000.0 * pulseDtMs);
            articulator.MoveDown();
            TEST.Assert.AreEqual(expected, articulator.CurAlt);
        }

        [TEST.TestMethod]
        public void SlewLeftTest()
        {
            float startAz = 0;
            int pulseDtMs = 100;
            int azRate = 10;

            MY.TelescopeArticulator articulator =
                new MY.TelescopeArticulator(0, 10, startAz, azRate, pulseDtMs);

            TEST.Assert.AreEqual(startAz, articulator.CurAz);

            float expected = articulator.CurAz - (float)(azRate / 1000.0 * pulseDtMs);
            articulator.MoveLeft();
            TEST.Assert.AreEqual(expected, articulator.CurAz);
        }

        [TEST.TestMethod]
        public void SlewUpTest()
        {
            float startAlt = 0;
            int altRate = 10;
            int pulseDtMs = 100;

            MY.TelescopeArticulator articulator =
                new MY.TelescopeArticulator(startAlt, altRate, 0, 10, pulseDtMs);

            TEST.Assert.AreEqual(startAlt, articulator.CurAlt);

            float expected = articulator.CurAlt + (float)(altRate / 1000.0 * pulseDtMs);
            articulator.MoveUp();
            TEST.Assert.AreEqual(expected, articulator.CurAlt);
        }

        [TEST.TestMethod]
        public void ResetSlewTest()
        {
            float startAlt = 0;
            int altRate = 10;

            float startAz = 0;
            int azRate = 10;

            int pulseDtMs = 100;

            MY.TelescopeArticulator articulator = 
                new MY.TelescopeArticulator(startAlt, altRate, startAz, azRate, pulseDtMs);

            TEST.Assert.AreEqual(startAlt, articulator.CurAlt);
            TEST.Assert.AreEqual(startAz, articulator.CurAz);
            TEST.Assert.AreEqual(altRate, articulator.AltRate);
            TEST.Assert.AreEqual(azRate, articulator.AzRate);

            float expected = articulator.CurAlt + (float)(altRate / 1000.0 * pulseDtMs);
            articulator.MoveUp();
            TEST.Assert.AreEqual(expected, articulator.CurAlt);

            expected = articulator.CurAz - (float)(azRate / 1000.0 * pulseDtMs);
            articulator.MoveLeft();
            TEST.Assert.AreEqual(expected, articulator.CurAz);

            articulator.ResetSlew();
            TEST.Assert.AreEqual(startAlt, articulator.CurAlt);
            TEST.Assert.AreEqual(startAz, articulator.CurAz);
        }

    }
}
