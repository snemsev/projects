﻿using MODEL = System.ComponentModel;

namespace VirtualTelescopeControlUI
{
    /// <summary>
    /// This class's purpose is to implement the INotifyPropertyChanged interface so
    /// that view models that extend it can be used as data contexts for views.
    /// </summary>
    public class ViewModelBase : MODEL.INotifyPropertyChanged
    {
        public event MODEL.PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new MODEL.PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
