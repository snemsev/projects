﻿using WINDOWS = System.Windows;

namespace VirtualTelescopeControlUI
{
    /// <summary>
    /// Used to transport data and commands between the view and the model.
    /// </summary>
    public class VirtualTelescopeControlViewModel : ViewModelBase
    {
        #region Private Memebers
        private const int _buttonPulseDtMs = 100;

        // This is our model (although in this case it has some business logic
        // as well).
        private TelescopeArticulator _articulator;

        // Used by this object to implement thread safety.
        private object _myLock;

        /// <summary>
        /// Recieves and reacts to the event that is raised by the model when
        /// the altitude has changed.
        /// </summary>
        /// 
        /// <param name="newVal">
        /// The new altitude value.
        /// </param>
        private void HandleAltChanged(float newVal)
        {
            NotifyPropertyChanged("CurAlt");
        }

        /// <summary>
        /// Recieves and reacts to the event that is raised by the model when
        /// the azimuth has changed.
        /// </summary>
        /// 
        /// <param name="newVal">
        /// The new altitude value.
        /// </param>
        private void HandleAzChanged(float newVal)
        {
            NotifyPropertyChanged("CurAz");
        }
        
        /// <summary>
        /// Register's with the model for changes to relevant fields.
        /// </summary>
        private void RegisterWithModel()
        {
            lock (_myLock)
            {
                _articulator.CurAltChanged += HandleAltChanged;
                _articulator.CurAzChanged += HandleAzChanged;
            }
        }

        /// <summary>
        /// Links the button command that is triggered by the view to the handler
        /// for that command.
        /// </summary>
        private void SetUpButtonHandlers()
        {
            lock (_myLock)
            {
                RightButtonCommand = new CommandForwarder(x => RightButtonClick("RightButton"));
                DownButtonCommand = new CommandForwarder(x => DownButtonClick("DownButton"));
                DownLeftButtonCommand = new CommandForwarder(x => DownLeftButtonClick("DownLeftButton"));
                DownRightButtonCommand = new CommandForwarder(x => DownRightButtonClick("DownRightButton"));
                LeftButtonCommand = new CommandForwarder(x => LeftButtonClick("LeftButton"));
                UpButtonCommand = new CommandForwarder(x => UpButtonClick("UpButton"));
                UpLeftButtonCommand = new CommandForwarder(x => UpLeftButtonClick("UpLeftButton"));
                UpRightButtonCommand = new CommandForwarder(x => UpRightButtonClick("UpRightButton"));
                ResetButtonCommand = new CommandForwarder(x => ResetButtonClick("UpRightButton"));
            }
        }
        #endregion

        #region Click Handlers
        // The view binds its slew right button command property to this property.               
        public WINDOWS.Input.ICommand RightButtonCommand { get; set; }

        // The view binds its slew down button command property to this property.
        public WINDOWS.Input.ICommand DownButtonCommand { get; set; }

        // The view binds its slew down-right button command property to this property.
        public WINDOWS.Input.ICommand DownRightButtonCommand { get; set; }

        // The view binds its slew down-left button command property to this property.
        public WINDOWS.Input.ICommand DownLeftButtonCommand { get; set; }

        // The view binds its slew left button command property to this property.
        public WINDOWS.Input.ICommand LeftButtonCommand { get; set; }

        // The view binds its slew up button command property to this property.
        public WINDOWS.Input.ICommand UpButtonCommand { get; set; }

        // The view binds its slew up-left button command property to this property.
        public WINDOWS.Input.ICommand UpLeftButtonCommand { get; set; }

        // The view binds its slew up-right button command property to this property.
        public WINDOWS.Input.ICommand UpRightButtonCommand { get; set; }

        // The view binds its reset slew button command property to this property.
        public WINDOWS.Input.ICommand ResetButtonCommand { get; set; }

        #endregion

        #region Click Executors

        /// <summary>
        /// Forwards the click command from the slew right button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void RightButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveRight();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew down button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void DownButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveDown();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew left button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void LeftButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveLeft();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew up button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void UpButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveUp();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew up-left button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void UpLeftButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveUp();
                _articulator.MoveLeft();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew up-right button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void UpRightButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveUp();
                _articulator.MoveRight();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew down-left button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void DownLeftButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveDown();
                _articulator.MoveLeft();
            }
        }

        /// <summary>
        /// Forwards the click command from the slew down-right button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void DownRightButtonClick(object sender)
        {
            lock (_myLock)
            {
                _articulator.MoveDown();
                _articulator.MoveRight();
            }
        }

        /// <summary>
        /// Forwards the click command from the reset slew button to the model.
        /// </summary>
        /// 
        /// <param name="sender">
        /// The object that raiesed this event.
        /// </param>
        private void ResetButtonClick(object sender)
        {
            lock(_myLock)
            {
                _articulator.ResetSlew();
            }
        }

        #endregion

        #region Constructors
        public VirtualTelescopeControlViewModel() 
        {
            _articulator = new TelescopeArticulator(0,0,0,0,_buttonPulseDtMs);
            _myLock = new object();
            RegisterWithModel();
            SetUpButtonHandlers();
        }

        #endregion

        #region Data Bindings

        /// <summary>
        /// Shuttles the button pulse timne frequency between the view and
        /// the model.
        /// </summary>
        public int ButtonPulseDtMs
        {
            get
            {
                int retVal;

                lock (_myLock)
                {
                    retVal = _buttonPulseDtMs;
                }

                return retVal;
            }
        }

        /// <summary>
        /// Shuttles the altitude change rate between the view and the model.
        /// </summary>
        public float AltRate
        {
            get
            {
                float retVal;

                lock (_myLock)
                {
                    retVal = _articulator.AltRate;
                }

                return retVal;
            }
            set
            {
                lock (_myLock)
                {
                    _articulator.AltRate = value;
                }

                NotifyPropertyChanged("AltRate");
            }
        }

        /// <summary>
        /// Shuttles the azimuth change rate between the view and the model.
        /// </summary>
        public float AzRate
        {
            get
            {
                float retVal;

                lock (_myLock)
                {
                    retVal = _articulator.AzRate;
                }

                return retVal;
            }
            set
            {
                lock (_myLock)
                {
                    _articulator.AzRate = value;
                    NotifyPropertyChanged("AzRate");
                }
            }
        }

        /// <summary>
        /// Shuttles the altitude value between the view and the model.
        /// </summary>
        public string CurAlt
        {
            get
            {
                string retVal = string.Empty;

                lock (_myLock)
                {
                    retVal = _articulator.CurAlt.ToString("0.00");
                }
                return retVal;
            }
        }

        /// <summary>
        /// Shuttles the azimuth value between the view and the model.
        /// </summary>
        public string CurAz
        {
            get
            {
                string retVal =  string.Empty;

                lock (_myLock)
                {
                    retVal = _articulator.CurAz.ToString("0.00");
                }

                return retVal;
            }
        }

        #endregion
    }
}
