﻿namespace VirtualTelescopeControlUI
{
    /// <summary>
    /// This class controls the slewing of the telescope based on slew rates and
    /// slew direction supplied by its consumer. The slewing is driven by a pulse
    /// for each direction. The amount that the telescope slews per pulse is
    /// determined bythe number of milliseconds that pass between consecutive pulses
    /// and the slew rate of each axis (alt/az).
    /// </summary>
    public class TelescopeArticulator
    {
        #region Private Members

        private object _myLock;

        // Azimuth constants
        private const float _maxAz = 180;
        private const float _minAz = -180;

        // Altitude constants
        private const float _maxAlt = 90;
        private const float _minAlt = -90;

        // Used to figure out how much to advance the altitude per pulse
        private float _altStepSize;

        // Used to figure out how much to advance the azimuth per pulse
        private float _azStepSize;

        private float _altRate;
        private float _azRate;

        // The number of milliseconds that pass between successive move commands.
        // This is used to compute the step size.
        private int _pulseTimeMs;
        private float _curAlt;
        private float _curAz;

        /// <summary>
        /// Constrains the supplied value to be on [_minAz, _maxAz]. This simplified
        /// implementation does not advance past min or max (i.e. the telescope does
        /// not slew past a particular limit).
        /// </summary>
        /// 
        /// <param name="rawVal"></param>
        /// <returns></returns>
        private float NormalizeAz(float rawVal)
        {
            float retVal = rawVal;

            if(retVal > _maxAz)
            {
                retVal = _maxAz;
            }
            else if(retVal < _minAz)
            {
                retVal = _minAz;
            }

            return retVal;
        }

        /// <summary>
        /// Constrains the supplied value to be on [_minAlt, _maxAlt]. This simplified
        /// implementation does not advance past min or max (i.e. the telescope does
        /// not slew past a particular limit).
        /// </summary>
        /// 
        /// <param name="rawVal">Value to normalize.</param>
        /// <returns>The normalized value.</returns>
        private float NormalizeAlt(float rawVal)
        {
            float retVal = rawVal;

            if (retVal > _maxAlt)
            {
                retVal = _maxAlt;
            }
            else if (retVal < _minAlt)
            {
                retVal = _minAlt;
            }

            return retVal;
        }

        
        #endregion


        #region Public Members

        public float CurAlt
        {
            get
            {
                float retVal;
                lock (_myLock) {
                    retVal = _curAlt;
                }
                return retVal;
            }
        }

        public float CurAz
        {
            get
            {
                float retVal;
                lock(_myLock)
                {
                    retVal = _curAz;
                }
                return retVal;
            }
        }

        public float AltRate
        {
            get
            {
                float retVal;
                lock (_myLock)
                {
                    retVal = _altRate;
                }
                return retVal;
            }
            set
            {
                lock(_myLock)
                {                    
                    _altRate = value;
                    _altStepSize = _altRate / 1000 * _pulseTimeMs;
                }
            }
        }

        public float AzRate
        {
            get
            {
                float retVal;
                lock (_myLock)
                {
                    retVal = _azRate;
                }
                return retVal;
            }
            set
            {
                lock (_myLock)
                {                    
                    _azRate = value;
                    _azStepSize = _azRate / 1000 * _pulseTimeMs;
                }
            }
        }

        public delegate void FloatValChanged(float newVal);

        // Used to tell clients when the azimuth value changes.
        public event FloatValChanged CurAzChanged;

        // Used to tell clients when the altitude value changes.
        public event FloatValChanged CurAltChanged;

        public TelescopeArticulator(float alt, float altRate, float az, float azRate, int pulseTime)
        {
            _myLock = new object();
            _altRate = altRate;
            _azRate = azRate;
            _curAlt = alt;
            _curAz = az;
            _pulseTimeMs = pulseTime;
            _altStepSize = altRate / 1000 * _pulseTimeMs;
            _azStepSize = azRate / 1000 * _pulseTimeMs;
        }

        public void MoveRight()
        {
            float newVal;

            lock (_myLock)
            {
                _curAz += _azStepSize;
                _curAz = NormalizeAz(_curAz);
                newVal = _curAz;

                if (CurAzChanged != null)
                {
                    CurAzChanged(newVal);
                }
            }
        }

        public void MoveDown()
        {
            float newVal;

            lock (_myLock)
            {
                _curAlt -= _altStepSize;
                _curAlt = NormalizeAlt(_curAlt);
                newVal = _curAlt;

                if (CurAltChanged != null)
                {
                    CurAltChanged(newVal);
                }
            }
        }

        public void MoveLeft()
        {
            float newVal;

            lock (_myLock)
            {
                _curAz -= _azStepSize;
                _curAz = NormalizeAz(_curAz);
                newVal = _curAz;
            }

            if (CurAzChanged != null)
            {
                CurAzChanged(newVal);
            }
        }    

        public void MoveUp()
        {
            float newVal;

            lock (_myLock)
            {
                _curAlt += _altStepSize;
                _curAlt = NormalizeAlt(_curAlt);
                newVal = _curAlt;
                if (CurAltChanged != null)
                {
                    CurAltChanged(newVal);
                }
            }
        }

        public void ResetSlew()
        {
            lock (_myLock)
            {
                float altResetVal = 0;
                float azResetVal = 0;
                _curAlt = altResetVal;
                _curAz = azResetVal;
                
                if (CurAltChanged != null)
                {
                    CurAltChanged(altResetVal);
                }

                if (CurAzChanged != null)
                {
                    CurAzChanged(azResetVal);
                }
            }
        }

        #endregion

    }
}
