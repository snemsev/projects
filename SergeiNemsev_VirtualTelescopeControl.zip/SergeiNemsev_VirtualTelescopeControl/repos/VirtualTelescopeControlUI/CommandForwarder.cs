﻿using System;
using WININ = System.Windows.Input;

namespace VirtualTelescopeControlUI
{
    /// <summary>
    /// This class is capable piping commands sent by the view to event handlers
    /// that are in the view model.
    /// </summary>
    public class CommandForwarder : WININ.ICommand
    {
        #region Private Members

        private readonly Action<object> _forward;
        private readonly Predicate<object> _forwardPredicate;

        #endregion

        #region Constructors

        public CommandForwarder(Action<object> forward, Predicate<object> forwardPredicate = null)
        {
            if (forward == null)
            {
                throw new ArgumentNullException("forward is not allowed to be null");
            }

            _forward = forward;
            _forwardPredicate = forwardPredicate;
        }

        #endregion

        #region ICommand Implementation

        public bool CanExecute(object parameter)
        {
            return _forwardPredicate == null || _forwardPredicate(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { WININ.CommandManager.RequerySuggested += value; }
            remove { WININ.CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            _forward(parameter ?? "<N/A>");
        }
        #endregion

    }
}